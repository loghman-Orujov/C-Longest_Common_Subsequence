#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void removeSpaces(char *str) {
    int len = strlen(str);
    int i, j = 0;
    for (i = 0; i < len; i++) {
        if (str[i] != ' ') {
            str[j++] = str[i];
        }
    }
    str[j] = '\0'; // Yeni sonland�r�c� karakteri ekle
}

int max(int a, int b) {
    return (a > b) ? a : b;
}

int find(int a, int b) {
    if (a == b) return 3;
    else if (a > b) return 1;
    else return 2;
}

void printLCS(char *X, char *result, int len) {
    printf("%.*s\n", len, result);
}

void findLCS(char *X, char *Y, int m, int n, int **L, int **B, char *result, int index, int *len) {
    if (m == 0 || n == 0) {
        printLCS(X, result, *len);
        return;
    }
    if (B[m][n] == 0) {
        result[index - 1] = X[m - 1];
        findLCS(X, Y, m - 1, n - 1, L, B, result, index - 1, len);
    } else if (B[m][n] == 1) {
        findLCS(X, Y, m - 1, n, L, B, result, index, len);
    } else if (B[m][n] == 2) {
        findLCS(X, Y, m, n - 1, L, B, result, index, len);
    } else {
        if (L[m - 1][n] > L[m][n - 1]) {
            findLCS(X, Y, m - 1, n, L, B, result, index, len);
        } else if (L[m][n - 1] > L[m - 1][n]) {
            findLCS(X, Y, m, n - 1, L, B, result, index, len);
        } else {
            findLCS(X, Y, m - 1, n, L, B, result, index, len);
            findLCS(X, Y, m, n - 1, L, B, result, index, len);
        }
    }
}

void enUzunOrtakSekans(char *X, char *Y) {
    int m = strlen(X);
    int n = strlen(Y);

    int **L = (int **)malloc((m + 1) * sizeof(int *));
    int **B = (int **)malloc((m + 1) * sizeof(int *));
    int i, j;

    for (i = 0; i < m + 1; i++) {
        L[i] = (int *)malloc((n + 1) * sizeof(int));
        B[i] = (int *)malloc((n + 1) * sizeof(int));
    }

    for (i = 0; i <= m; i++) {
        for (j = 0; j <= n; j++) {
            if (i == 0 || j == 0) {
                L[i][j] = 0;
                B[i][j] = 0;
            } else if (X[i - 1] == Y[j - 1]) {
                L[i][j] = L[i - 1][j - 1] + 1;
                B[i][j] = 0;
            } else {
                L[i][j] = max(L[i - 1][j], L[i][j - 1]);
                B[i][j] = find(L[i - 1][j], L[i][j - 1]);
            }
        }
    }
     printf("Dinamik Programlama Matrisi:\n");
    for (i = 0; i <= m; i++) {
        for (j = 0; j <= n; j++) {
            printf("%d ", L[i][j]);
        }
        printf("\n");
    }
    printf("\n");
    for (i = 0; i <= m; i++) {
        for (j = 0; j <= n; j++) {
            printf("%d ", B[i][j]);
        }
        printf("\n");
    }
    printf("\n");

    int length = L[m][n];
    char *result = (char *)malloc((length + 1) * sizeof(char));
    result[length] = '\0';

    printf("En uzun ifadenin boyutu: %d\n", length);
    printf("En uzun ortak sekans(lar):\n");

    findLCS(X, Y, m, n, L, B, result, length, &length);

    free(result);
    for (i = 0; i < m + 1; i++) {
        free(L[i]);
        free(B[i]);
    }
    free(L);
    free(B);
}

int main() {
    char string1[100];
    char string2[100];

  

printf("String 1: ");
fgets(string1, sizeof(string1), stdin);

printf("String 2: ");
fgets(string2, sizeof(string2), stdin);
 // Bo�luklar� kald�r
    removeSpaces(string1);
    removeSpaces(string2);
    string1[strcspn(string1, "\n")] = '\0';
string2[strcspn(string2, "\n")] = '\0';
    

    enUzunOrtakSekans(string1, string2);

    return 0;
}

